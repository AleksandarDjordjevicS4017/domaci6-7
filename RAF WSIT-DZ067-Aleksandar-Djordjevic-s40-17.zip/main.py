from flask import Flask, render_template,redirect, url_for, request, session
from flask_mysqldb import MySQL
from pymongo import MongoClient
from bson import ObjectId
from datetime import datetime
import hashlib
import time
import mysql.connector

mydb = mysql.connector.connect(
	host="localhost",
	user="root",
	password="",
	database="rasporedi"  
)


app = Flask(__name__)
app.config['SECRET_KEY'] = 'localhost'
app.config('MYSQL_USER') = 'root'
app.config('MYSQL_PASSWORD') = ''
app.config('MYSQL_DB') = 'rasporedi'

mysql = MySql(app)
@app.route("/rasporedi")
def pocetna():
	cur = mysql.connection.cursor()
	cur.execute("SELECT * FROM raspored")
	fetchdata = cur.fetchall()
	cur.close()

	return render_template("pocetna.html", data  = fetchdata)






if __name__ == '__main__':
	app.run(debug=True)
